"""DirectX/HLSL AST Node definitions"""

from ..common_ast import (
    ArrayAccessNode,
    AssignmentNode,
    ASTNode,
    AttributeNode,
    BinaryOpNode,
    BreakNode,
    CaseNode,
    CastNode,
    ContinueNode,
    DoWhileNode,
    EnumNode,
    ForNode,
    FunctionCallNode,
    FunctionNode,
    IfNode,
    MemberAccessNode,
    PreprocessorNode,
    ReturnNode,
    ShaderNode,
    StructNode,
    SwitchNode,
    TernaryOpNode,
    TextureSampleNode,
    TypeAliasNode,
    UnaryOpNode,
    VariableNode,
    VectorConstructorNode,
    WhileNode,
)

_COMMON_NODES = (
    ASTNode,
    ArrayAccessNode,
    AssignmentNode,
    AttributeNode,
    BinaryOpNode,
    BreakNode,
    CaseNode,
    CastNode,
    ContinueNode,
    DoWhileNode,
    EnumNode,
    ForNode,
    FunctionCallNode,
    FunctionNode,
    IfNode,
    MemberAccessNode,
    PreprocessorNode,
    ReturnNode,
    ShaderNode,
    StructNode,
    SwitchNode,
    TernaryOpNode,
    TextureSampleNode,
    TypeAliasNode,
    UnaryOpNode,
    VariableNode,
    VectorConstructorNode,
    WhileNode,
)

# DirectX-specific nodes


class CbufferNode(StructNode):
    """HLSL constant-buffer declaration with named member variables."""

    def __init__(self, name, members):
        super().__init__(name, members)

    def __repr__(self):
        return f"CbufferNode(name={self.name}, members={self.members})"


class PragmaNode(ASTNode):
    """Preprocessor pragma directive preserved in the HLSL AST."""

    def __init__(self, directive, value=None):
        self.directive = directive
        self.value = value

    def __repr__(self):
        return f"PragmaNode(directive={self.directive}, value={self.value})"


class IncludeNode(ASTNode):
    """HLSL include directive with system/local include metadata."""

    def __init__(self, path, is_system=False):
        self.path = path
        self.is_system = is_system

    def __repr__(self):
        return f"IncludeNode(path={self.path}, is_system={self.is_system})"


class SwitchStatementNode(ASTNode):
    """Legacy switch statement node used by older HLSL parser paths."""

    def __init__(self, expression, cases):
        self.expression = expression
        self.cases = cases

    def __repr__(self):
        return f"SwitchStatementNode(expression={self.expression}, cases={self.cases})"


class SwitchCaseNode(ASTNode):
    """Legacy switch case node with default-case tracking."""

    def __init__(self, case_value, statements, is_default=False):
        self.case_value = case_value
        self.statements = statements
        self.is_default = is_default

    def __repr__(self):
        return f"SwitchCaseNode(case_value={self.case_value}, statements={len(self.statements)}, is_default={self.is_default})"
