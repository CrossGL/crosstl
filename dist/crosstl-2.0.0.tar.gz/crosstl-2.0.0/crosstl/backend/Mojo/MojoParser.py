"""Parser for Mojo source AST construction."""

from .MojoAst import *
from .MojoLexer import *


class MojoParser:
    """Parse Mojo tokens into the Mojo backend AST."""

    STATEMENT_END_TOKENS = {"NEWLINE", "DEDENT", "EOF", "RBRACE"}
    ATTRIBUTE_START_TOKENS = {"ATTRIBUTE", "AT"}
    FUNCTION_TOKENS = {"FN", "DEF"}
    TYPE_START_TOKENS = {"IDENTIFIER", "INT", "FLOAT", "BOOL", "STRING"}

    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.current_token = self.tokens[self.pos]
        self.skip_comments()

    def skip_comments(self):
        while self.current_token[0] in ["COMMENT_SINGLE", "COMMENT_MULTI"]:
            self.eat(self.current_token[0])

    def skip_newlines(self):
        while self.current_token[0] == "NEWLINE":
            self.eat("NEWLINE")

    def skip_layout_tokens(self):
        while self.current_token[0] in ["NEWLINE", "INDENT", "DEDENT"]:
            self.eat(self.current_token[0])

    def consume_statement_terminator(self):
        if self.current_token[0] == "SEMICOLON":
            self.eat("SEMICOLON")
            return

        if self.current_token[0] in self.STATEMENT_END_TOKENS:
            return

        raise SyntaxError(f"Expected end of statement, got {self.current_token[0]}")

    def attach_attributes(self, node, attributes):
        if attributes:
            existing_attributes = getattr(node, "attributes", [])
            node.attributes = attributes + existing_attributes
        return node

    def eat(self, token_type):
        if self.current_token[0] == token_type:
            self.pos += 1
            self.current_token = (
                self.tokens[self.pos] if self.pos < len(self.tokens) else ("EOF", None)
            )
            self.skip_comments()
        else:
            raise SyntaxError(f"Expected {token_type}, got {self.current_token[0]}")

    def peek_token(self, offset=1):
        index = self.pos + offset
        if index < len(self.tokens):
            return self.tokens[index]
        return ("EOF", None)

    def parse(self):
        module = self.parse_module()
        self.eat("EOF")
        return module

    def parse_module(self):
        imports = []
        structs = []
        functions = []
        global_variables = []
        constants = []
        classes = []
        all_items = []

        while self.current_token[0] != "EOF":
            if self.current_token[0] in ["NEWLINE", "INDENT", "DEDENT"]:
                self.eat(self.current_token[0])
                continue

            attributes = self.parse_attributes()
            if attributes and self.current_token[0] == "EOF":
                raise SyntaxError("Expected declaration after attribute")

            if self.current_token[0] in ["IMPORT", "FROM"]:
                node = self.parse_import_statement()
                imports.append(node)
                all_items.append(node)
            elif self.current_token[0] == "STRUCT":
                node = self.parse_struct(attributes)
                structs.append(node)
                all_items.append(node)
            elif self.current_token[0] == "CLASS":
                node = self.parse_class(attributes)
                classes.append(node)
                all_items.append(node)
            elif self.current_token[0] == "CONSTANT":
                node = self.parse_constant_buffer()
                self.attach_attributes(node, attributes)
                constants.append(node)
                all_items.append(node)
            elif self.current_token[0] in self.FUNCTION_TOKENS:
                node = self.parse_function(attributes)
                functions.append(node)
                all_items.append(node)
            elif self.current_token[0] in ["LET", "VAR"]:
                node = self.parse_variable_declaration_or_assignment()
                self.attach_attributes(node, attributes)
                global_variables.append(node)
                all_items.append(node)
            elif self.current_token[0] == "DECORATOR":
                node = self.parse_decorator()
                all_items.append(node)
            else:
                if attributes:
                    raise SyntaxError("Expected declaration after attribute")
                token_type, token_value = self.current_token
                raise SyntaxError(
                    f"Unexpected top-level token: {token_type} {token_value!r}"
                )

        return ShaderNode(
            includes=imports,
            functions=all_items,
            structs=structs,
            global_variables=global_variables,
            constants=constants,
            classes=classes,
        )

    def parse_import_statement(self):
        if self.current_token[0] == "FROM":
            self.eat("FROM")
            module_name = self.parse_import_path()
            self.eat("IMPORT")
            items = self.parse_import_items()
            self.consume_statement_terminator()
            self.skip_newlines()
            return ImportNode(module_name, items=items)

        self.eat("IMPORT")
        module_name = self.parse_import_path()
        alias = None
        if self.current_token[0] == "AS":
            self.eat("AS")
            alias = self.current_token[1]
            self.eat("IDENTIFIER")
        self.consume_statement_terminator()
        self.skip_newlines()
        return ImportNode(module_name, alias=alias)

    def parse_import_path(self):
        name = self.current_token[1]
        self.eat("IDENTIFIER")
        while self.current_token[0] == "DOT":
            self.eat("DOT")
            name += f".{self.current_token[1]}"
            self.eat("IDENTIFIER")
        return name

    def parse_import_items(self):
        items = []
        while self.current_token[0] not in self.STATEMENT_END_TOKENS | {"SEMICOLON"}:
            if self.current_token[0] == "MULTIPLY":
                item = self.current_token[1]
                self.eat("MULTIPLY")
            else:
                item = self.parse_import_path()

            if self.current_token[0] == "AS":
                self.eat("AS")
                alias = self.current_token[1]
                self.eat("IDENTIFIER")
                item = f"{item} as {alias}"

            items.append(item)
            if self.current_token[0] == "COMMA":
                self.eat("COMMA")
            else:
                break

        if not items:
            raise SyntaxError("Expected imported item")
        return items

    def parse_struct(self, initial_attributes=None):
        self.eat("STRUCT")
        name = self.current_token[1]
        self.eat("IDENTIFIER")

        members = []

        if self.current_token[0] == "LBRACE":
            self.eat("LBRACE")
            while self.current_token[0] not in ["RBRACE", "EOF"]:
                if self.current_token[0] in ["NEWLINE", "INDENT", "DEDENT"]:
                    self.eat(self.current_token[0])
                    continue
                members.append(self.parse_struct_member())
                self.skip_newlines()
            if self.current_token[0] == "RBRACE":
                self.eat("RBRACE")
        elif self.current_token[0] == "COLON":
            self.eat("COLON")
            self.skip_newlines()
            if self.current_token[0] == "INDENT":
                self.eat("INDENT")
            while (
                self.current_token[0] != "EOF"
                and self.current_token[0] != "DEDENT"
                and self.current_token[0] not in ["FN", "DEF", "STRUCT", "CLASS"]
            ):
                self.skip_newlines()
                if self.current_token[0] in ["DEDENT", "EOF"]:
                    break
                members.append(self.parse_struct_member())
                self.skip_newlines()

            if self.current_token[0] == "DEDENT":
                self.eat("DEDENT")
        else:
            raise SyntaxError(f"Expected struct body, got {self.current_token[0]}")

        return StructNode(name, members, attributes=initial_attributes)

    def parse_struct_member(self):
        return self.parse_typed_member("struct")

    def parse_typed_member(self, context, initial_attributes=None):
        self.skip_newlines()
        member_attributes = list(initial_attributes or [])
        member_attributes.extend(self.parse_attributes())

        if self.current_token[0] in ["DEDENT", "EOF", "RBRACE"]:
            raise SyntaxError(f"Expected {context} member")

        if self.current_token[0] in ["LET", "VAR"]:
            vtype = self.current_token[1]
            self.eat(self.current_token[0])
            var_name = self.current_token[1]
            self.eat("IDENTIFIER")
            if self.current_token[0] == "COLON":
                self.eat("COLON")
                vtype = self.parse_type()
        elif self.peek_token()[0] == "COLON":
            var_name = self.current_token[1]
            self.eat("IDENTIFIER")
            self.eat("COLON")
            vtype = self.parse_type()
        else:
            if self.current_token[0] not in self.TYPE_START_TOKENS:
                if member_attributes:
                    raise SyntaxError(f"Expected {context} member after attribute")
                raise SyntaxError(
                    f"Unexpected token in {context}: {self.current_token[0]}"
                )
            vtype = self.parse_type()
            var_name = self.current_token[1]
            self.eat("IDENTIFIER")

        member_attributes.extend(self.parse_attributes(skip_trailing_newlines=False))
        self.consume_statement_terminator()
        return VariableNode(vtype, var_name, attributes=member_attributes)

    def parse_class(self, initial_attributes=None):
        self.eat("CLASS")
        name = self.current_token[1]
        self.eat("IDENTIFIER")
        base_classes = []
        if self.current_token[0] == "LPAREN":
            self.eat("LPAREN")
            while self.current_token[0] != "RPAREN":
                base_classes.append(self.current_token[1])
                self.eat("IDENTIFIER")
                if self.current_token[0] == "COMMA":
                    self.eat("COMMA")
            self.eat("RPAREN")

        members = []
        methods = []

        if self.current_token[0] == "LBRACE":
            self.eat("LBRACE")
            while self.current_token[0] not in ["RBRACE", "EOF"]:
                if self.current_token[0] in ["NEWLINE", "INDENT", "DEDENT"]:
                    self.eat(self.current_token[0])
                    continue
                self.add_class_member(members, methods, self.parse_class_member())
            if self.current_token[0] == "RBRACE":
                self.eat("RBRACE")
        elif self.current_token[0] == "COLON":
            self.eat("COLON")
            self.skip_newlines()
            if self.current_token[0] == "INDENT":
                self.eat("INDENT")
                while self.current_token[0] not in ["DEDENT", "EOF"]:
                    self.skip_newlines()
                    if self.current_token[0] in ["DEDENT", "EOF"]:
                        break
                    self.add_class_member(members, methods, self.parse_class_member())
                    self.skip_newlines()
                if self.current_token[0] == "DEDENT":
                    self.eat("DEDENT")
            else:
                self.add_class_member(members, methods, self.parse_class_member())
        else:
            raise SyntaxError(f"Expected class body, got {self.current_token[0]}")

        return ClassNode(
            name,
            members=members,
            methods=methods,
            base_classes=base_classes,
            attributes=initial_attributes,
        )

    def parse_class_member(self):
        self.skip_newlines()
        attributes = self.parse_attributes()

        if self.current_token[0] in self.FUNCTION_TOKENS:
            return self.parse_function(attributes)
        if self.current_token[0] == "CLASS":
            return self.parse_class(attributes)
        if self.current_token[0] in ["LET", "VAR"]:
            member = self.parse_variable_declaration_or_assignment()
            return self.attach_attributes(member, attributes)
        if self.current_token[0] in self.TYPE_START_TOKENS:
            return self.parse_typed_member("class", attributes)

        if attributes:
            raise SyntaxError("Expected class member after attribute")
        raise SyntaxError(f"Unexpected token in class body: {self.current_token[0]}")

    def add_class_member(self, members, methods, node):
        if isinstance(node, FunctionNode):
            methods.append(node)
        else:
            members.append(node)

    def parse_constant_buffer(self):
        self.eat("CONSTANT")
        name = self.current_token[1]
        self.eat("IDENTIFIER")

        members = []

        if self.current_token[0] == "LBRACE":
            self.eat("LBRACE")
            while self.current_token[0] not in ["RBRACE", "EOF"]:
                if self.current_token[0] in ["NEWLINE", "INDENT", "DEDENT"]:
                    self.eat(self.current_token[0])
                    continue
                members.append(self.parse_constant_buffer_member())
            if self.current_token[0] == "RBRACE":
                self.eat("RBRACE")
        elif self.current_token[0] == "COLON":
            self.eat("COLON")
            self.skip_newlines()
            if self.current_token[0] == "INDENT":
                self.eat("INDENT")
                while self.current_token[0] not in ["DEDENT", "EOF"]:
                    self.skip_newlines()
                    if self.current_token[0] in ["DEDENT", "EOF"]:
                        break
                    members.append(self.parse_constant_buffer_member())
                    self.skip_newlines()
                if self.current_token[0] == "DEDENT":
                    self.eat("DEDENT")
            else:
                members.append(self.parse_constant_buffer_member())
        else:
            raise SyntaxError(
                f"Expected constant buffer body, got {self.current_token[0]}"
            )

        return ConstantBufferNode(name, members)

    def parse_constant_buffer_member(self):
        attributes = self.parse_attributes()

        if self.current_token[0] in ["LET", "VAR"]:
            member = self.parse_variable_declaration_or_assignment()
            return self.attach_attributes(member, attributes)

        if self.current_token[0] not in self.TYPE_START_TOKENS:
            if attributes:
                raise SyntaxError("Expected constant buffer member after attribute")
            raise SyntaxError(
                f"Unexpected token in constant buffer: {self.current_token[0]}"
            )

        if self.peek_token()[0] == "COLON":
            name = self.current_token[1]
            self.eat(self.current_token[0])
            self.eat("COLON")
            vtype = self.parse_type()
        else:
            vtype = self.parse_type()
            name = self.current_token[1]
            self.eat("IDENTIFIER")

        attributes.extend(self.parse_attributes(skip_trailing_newlines=False))
        self.consume_statement_terminator()
        return VariableNode(vtype, name, attributes=attributes)

    def parse_function(self, initial_attributes=None):
        attributes = list(initial_attributes or [])
        attributes.extend(self.parse_attributes())

        qualifier = None
        if self.current_token[0] in self.FUNCTION_TOKENS:
            self.eat(self.current_token[0])

        return_type = None
        name = self.current_token[1]
        self.eat("IDENTIFIER")

        self.eat("LPAREN")
        params = self.parse_parameters()
        self.eat("RPAREN")

        if self.current_token[0] == "MINUS":
            self.eat("MINUS")
            if self.current_token[0] == "GREATER_THAN":
                self.eat("GREATER_THAN")
                return_type = self.parse_type()

        post_attributes = self.parse_attributes()
        attributes.extend(post_attributes)

        if self.current_token[0] == "COLON":
            self.eat("COLON")

        body = self.parse_block()

        func = FunctionNode(
            return_type, name, params, body, qualifiers=[], attributes=attributes
        )
        func.qualifier = qualifier
        return func

    def parse_parameters(self):
        params = []
        while True:
            self.skip_layout_tokens()
            if self.current_token[0] == "RPAREN":
                break

            attributes = self.parse_attributes()
            self.skip_layout_tokens()

            if self.current_token[0] in self.TYPE_START_TOKENS:
                if self.peek_token()[0] == "COLON":
                    name = self.current_token[1]
                    self.eat(self.current_token[0])
                    self.eat("COLON")
                    vtype = self.parse_type()
                else:
                    vtype = self.parse_type()
                    name = ""
                    if self.current_token[0] == "IDENTIFIER":
                        name = self.current_token[1]
                        self.eat("IDENTIFIER")

                param_attributes = self.parse_attributes(skip_trailing_newlines=False)
                attributes.extend(param_attributes)

                params.append(VariableNode(vtype, name, attributes=attributes))
                self.skip_layout_tokens()

            else:
                raise SyntaxError(
                    f"Unexpected token in parameter list: {self.current_token[0]}"
                )

            if self.current_token[0] == "COMMA":
                self.eat("COMMA")
                self.skip_layout_tokens()
                if self.current_token[0] == "RPAREN":
                    raise SyntaxError("Trailing comma in parameter list is not allowed")
            elif self.current_token[0] == "RPAREN":
                break
            else:
                raise SyntaxError(
                    f"Expected comma or closing parenthesis, got {self.current_token[0]}"
                )

        return params

    def parse_attributes(self, skip_trailing_newlines=True):
        attributes = []
        while self.current_token[0] in self.ATTRIBUTE_START_TOKENS:
            if self.current_token[0] == "ATTRIBUTE":
                attr_content = self.current_token[1][2:-2]  # Remove [[ and ]]
                attr_parts = attr_content.split("(")
                if len(attr_parts) > 1:
                    name = attr_parts[0]
                    args = attr_parts[1][:-1].split(",")
                else:
                    name = attr_content
                    args = []
                attributes.append(AttributeNode(name, args))
                self.eat("ATTRIBUTE")
            else:
                self.eat("AT")
                if self.current_token[0] != "IDENTIFIER":
                    raise SyntaxError(
                        f"Expected attribute name, got {self.current_token[0]}"
                    )
                name = self.current_token[1]
                self.eat("IDENTIFIER")
                args = []
                if self.current_token[0] == "LPAREN":
                    self.eat("LPAREN")
                    while self.current_token[0] != "RPAREN":
                        args.append(self.parse_expression())
                        if self.current_token[0] == "COMMA":
                            self.eat("COMMA")
                        elif self.current_token[0] != "RPAREN":
                            raise SyntaxError(
                                f"Expected COMMA or RPAREN, got {self.current_token[0]}"
                            )
                    self.eat("RPAREN")
                attributes.append(AttributeNode(name, args))
            if skip_trailing_newlines:
                self.skip_newlines()
        return attributes

    def parse_block(self):
        self.skip_newlines()
        if self.current_token[0] == "LBRACE":
            self.eat("LBRACE")
            statements = []
            while self.current_token[0] != "RBRACE" and self.current_token[0] != "EOF":
                if self.current_token[0] == "NEWLINE":
                    self.eat("NEWLINE")
                    continue
                statements.append(self.parse_statement())
                self.skip_newlines()
            if self.current_token[0] == "RBRACE":
                self.eat("RBRACE")
            return statements
        elif self.current_token[0] == "INDENT":
            self.eat("INDENT")
            statements = []
            while self.current_token[0] not in ["DEDENT", "EOF"]:
                self.skip_newlines()
                if self.current_token[0] in ["DEDENT", "EOF"]:
                    break
                statements.append(self.parse_statement())
                self.skip_newlines()
            if self.current_token[0] == "DEDENT":
                self.eat("DEDENT")
            return statements
        else:
            statements = []
            if self.current_token[0] not in [
                "DEDENT",
                "EOF",
                "ELSE",
                "ELIF",
                "CASE",
                "DEFAULT",
            ]:
                statements.append(self.parse_statement())
            return statements

    def parse_statement(self):
        self.skip_newlines()
        if self.current_token[0] in [
            "FLOAT",
            "INT",
            "UINT",
            "BOOL",
            "IDENTIFIER",
            "LET",
            "VAR",
        ]:
            return self.parse_variable_declaration_or_assignment()

        elif self.current_token[0] in self.FUNCTION_TOKENS:
            return self.parse_function()
        elif self.current_token[0] == "IF":
            return self.parse_if_statement()
        elif self.current_token[0] == "FOR":
            return self.parse_for_statement()
        elif self.current_token[0] == "WHILE":
            return self.parse_while_statement()
        elif self.current_token[0] == "RETURN":
            return self.parse_return_statement()
        elif self.current_token[0] == "BREAK":
            self.eat("BREAK")
            self.consume_statement_terminator()
            return BreakNode()
        elif self.current_token[0] == "CONTINUE":
            self.eat("CONTINUE")
            self.consume_statement_terminator()
            return ContinueNode()
        elif self.current_token[0] == "PASS":
            self.eat("PASS")
            self.consume_statement_terminator()
            return PassNode()
        elif self.current_token[0] == "SWITCH":
            return self.parse_switch_statement()
        elif self.current_token[0] == "STRUCT":
            return self.parse_struct()
        else:
            return self.parse_expression_statement()

    def parse_variable_declaration_or_assignment(self):
        if self.current_token[0] in ["LET", "VAR"]:
            var_type = self.current_token[0]
            self.eat(self.current_token[0])
            name = self.current_token[1]
            self.eat("IDENTIFIER")

            attributes = []
            vtype = None
            if self.current_token[0] == "COLON":
                self.eat("COLON")
                vtype = self.parse_type()
                attributes.extend(self.parse_attributes(skip_trailing_newlines=False))

            initial_value = None
            if self.current_token[0] == "EQUALS":
                self.eat("EQUALS")
                initial_value = self.parse_expression()
                attributes.extend(self.parse_attributes(skip_trailing_newlines=False))

            self.consume_statement_terminator()

            return VariableDeclarationNode(
                vtype,
                name,
                initial_value,
                is_var=var_type == "VAR",
                attributes=attributes,
            )

        if self.current_token[0] == "IDENTIFIER" and self.peek_token()[0] == "COLON":
            name = self.current_token[1]
            self.eat("IDENTIFIER")
            self.eat("COLON")
            vtype = self.parse_type()
            attributes = self.parse_attributes(skip_trailing_newlines=False)
            self.consume_statement_terminator()
            return VariableNode(vtype, name, attributes=attributes)

        statement = self.parse_assignment()
        self.consume_statement_terminator()
        return statement

    def parse_if_statement(self):
        self.eat("IF")
        condition = self.parse_expression()
        self.eat("COLON")
        if_body = self.parse_block()
        self.skip_newlines()

        else_body = None
        while self.current_token[0] == "ELIF":
            self.eat("ELIF")
            elif_condition = self.parse_expression()
            self.eat("COLON")
            elif_body = self.parse_block()
            self.skip_newlines()
            elif_node = IfNode(elif_condition, elif_body, None)
            if else_body is None:
                else_body = [elif_node]
            else:
                current = else_body[0]
                while isinstance(current, IfNode) and current.else_body:
                    current = current.else_body[0]
                current.else_body = [elif_node]

        if self.current_token[0] == "ELSE":
            self.eat("ELSE")
            self.eat("COLON")
            final_else_body = self.parse_block()
            if else_body is None:
                else_body = final_else_body
            else:
                current = else_body[0]
                while isinstance(current, IfNode) and current.else_body:
                    current = current.else_body[0]
                current.else_body = final_else_body

        return IfNode(condition, if_body, else_body)

    def parse_for_statement(self):
        self.eat("FOR")

        saved_pos = self.pos
        saved_token = self.current_token

        try:
            init = self.parse_variable_declaration_or_assignment()
            if self.current_token[0] == "SEMICOLON":
                self.eat("SEMICOLON")

            condition = self.parse_expression()
            self.eat("SEMICOLON")
            update = self.parse_expression()
            self.eat("COLON")
            body = self.parse_block()
            return ForNode(init, condition, update, body)

        except Exception:
            self.pos = saved_pos
            self.current_token = saved_token

        if self.current_token[0] == "IDENTIFIER":
            var_name = self.current_token[1]
            self.eat("IDENTIFIER")
            if self.current_token[0] == "IN":
                self.eat("IN")
                iterable = self.parse_for_iterable()
                self.eat("COLON")
                body = self.parse_block()
                return RangeForNode("", var_name, iterable, body)

        raise SyntaxError(
            f"Invalid for loop syntax. Expected C-style 'for init; condition; update:' or Python-style 'for var in iterable:'"
        )

    def parse_for_iterable(self):
        if self.current_token[0] == "IDENTIFIER" and self.peek_token()[0] == "COLON":
            name = self.current_token[1]
            self.eat("IDENTIFIER")
            return VariableNode("", name)

        return self.parse_expression()

    def parse_while_statement(self):
        self.eat("WHILE")
        condition = self.parse_expression()
        self.eat("COLON")
        body = self.parse_block()
        return WhileNode(condition, body)

    def parse_switch_statement(self):
        self.eat("SWITCH")
        expression = self.parse_expression()
        self.eat("COLON")
        cases = []
        seen_default = False
        self.skip_newlines()
        if self.current_token[0] == "INDENT":
            self.eat("INDENT")
            self.skip_newlines()
            while self.current_token[0] in ["CASE", "DEFAULT"]:
                if self.current_token[0] == "DEFAULT":
                    if seen_default:
                        raise SyntaxError("duplicate default label in switch")
                    seen_default = True
                cases.append(self.parse_switch_case())
                self.skip_newlines()
            if self.current_token[0] == "DEDENT":
                self.eat("DEDENT")
        else:
            while self.current_token[0] in ["CASE", "DEFAULT"]:
                if self.current_token[0] == "DEFAULT":
                    if seen_default:
                        raise SyntaxError("duplicate default label in switch")
                    seen_default = True
                cases.append(self.parse_switch_case())
                self.skip_newlines()
        return SwitchNode(expression, cases)

    def parse_switch_case(self):
        if self.current_token[0] == "CASE":
            self.eat("CASE")
            condition = self.parse_expression()
            self.eat("COLON")
            body = self.parse_block()
            return SwitchCaseNode(condition, body)
        elif self.current_token[0] == "DEFAULT":
            self.eat("DEFAULT")
            self.eat("COLON")
            body = self.parse_block()
            return SwitchCaseNode(None, body)
        else:
            raise SyntaxError(
                f"Unexpected token in switch case: {self.current_token[0]}"
            )

    def parse_return_statement(self):
        self.eat("RETURN")
        if self.current_token[0] in [
            "SEMICOLON",
            "NEWLINE",
            "DEDENT",
            "EOF",
            "RBRACE",
        ]:
            value = None
        else:
            value = self.parse_expression()

        self.consume_statement_terminator()

        return ReturnNode(value)

    def parse_expression_statement(self):
        expr = self.parse_expression()
        self.consume_statement_terminator()
        return expr

    def parse_expression(self):
        return self.parse_assignment()

    def parse_assignment(self):
        left = self.parse_logical_or()
        if self.current_token[0] in [
            "EQUALS",
            "PLUS_EQUALS",
            "MINUS_EQUALS",
            "MULTIPLY_EQUALS",
            "DIVIDE_EQUALS",
            "ASSIGN_XOR",
            "ASSIGN_OR",
            "ASSIGN_AND",
            "ASSIGN_SHIFT_LEFT",
            "ASSIGN_SHIFT_RIGHT",
            "ASSIGN_MOD",
        ]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            right = self.parse_assignment()
            return AssignmentNode(left, right, op)
        if self.current_token[0] == "QUESTION":
            self.eat("QUESTION")
            true_expr = self.parse_expression()
            self.eat("COLON")
            false_expr = self.parse_expression()
            left = TernaryOpNode(left, true_expr, false_expr)
        if self.current_token[0] == "IF":
            true_expr = left
            self.eat("IF")
            condition = self.parse_expression()
            self.eat("ELSE")
            false_expr = self.parse_expression()
            left = TernaryOpNode(condition, true_expr, false_expr)
        return left

    def parse_logical_or(self):
        left = self.parse_logical_and()
        while self.current_token[0] == "OR":
            op = self.current_token[1]
            self.eat("OR")
            right = self.parse_logical_and()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_logical_and(self):
        left = self.parse_bitwise_or()
        while self.current_token[0] == "AND":
            op = self.current_token[1]
            self.eat("AND")
            right = self.parse_bitwise_or()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_bitwise_or(self):
        left = self.parse_bitwise_xor()
        while self.current_token[0] == "BITWISE_OR":
            op = self.current_token[1]
            self.eat("BITWISE_OR")
            right = self.parse_bitwise_xor()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_bitwise_xor(self):
        left = self.parse_bitwise_and()
        while self.current_token[0] == "BITWISE_XOR":
            op = self.current_token[1]
            self.eat("BITWISE_XOR")
            right = self.parse_bitwise_and()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_bitwise_and(self):
        left = self.parse_equality()
        while self.current_token[0] == "BITWISE_AND":
            op = self.current_token[1]
            self.eat("BITWISE_AND")
            right = self.parse_equality()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_equality(self):
        left = self.parse_relational()
        while self.current_token[0] in ["EQUAL", "NOT_EQUAL"]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            right = self.parse_relational()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_relational(self):
        left = self.parse_shift()
        while self.current_token[0] in [
            "LESS_THAN",
            "GREATER_THAN",
            "LESS_EQUAL",
            "GREATER_EQUAL",
        ]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            right = self.parse_shift()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_shift(self):
        left = self.parse_additive()
        while self.current_token[0] in ["SHIFT_LEFT", "SHIFT_RIGHT"]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            right = self.parse_additive()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_additive(self):
        left = self.parse_multiplicative()
        while self.current_token[0] in ["PLUS", "MINUS"]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            right = self.parse_multiplicative()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_multiplicative(self):
        left = self.parse_unary()
        while self.current_token[0] in ["MULTIPLY", "DIVIDE", "MOD"]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            right = self.parse_unary()
            left = BinaryOpNode(left, op, right)
        return left

    def parse_unary(self):
        if self.current_token[0] in ["PLUS", "MINUS", "BITWISE_NOT", "NOT"]:
            op = self.current_token[1]
            self.eat(self.current_token[0])
            operand = self.parse_unary()
            return UnaryOpNode(op, operand)
        return self.parse_primary()

    def parse_primary(self):
        if self.current_token[0] == "IDENTIFIER":
            return self.parse_function_call_or_identifier()
        elif self.current_token[0] == "NUMBER":
            value = self.current_token[1]
            self.eat("NUMBER")
            return self.parse_postfix_suffixes(value)
        elif self.current_token[0] == "STRING_LITERAL":
            value = self.current_token[1]
            self.eat("STRING_LITERAL")
            return self.parse_postfix_suffixes(value)
        elif self.current_token[0] == "BOOL_LITERAL":
            value = self.current_token[1]
            self.eat("BOOL_LITERAL")
            return self.parse_postfix_suffixes(value)
        elif self.current_token[0] in ["INT", "FLOAT", "BOOL", "STRING"]:
            type_name = self.current_token[1]
            self.eat(self.current_token[0])
            if self.current_token[0] == "IDENTIFIER":
                var_name = self.current_token[1]
                self.eat("IDENTIFIER")
                if self.current_token[0] == "COLON":
                    self.eat("COLON")
                    type_annotation = self.current_token[1]
                    self.eat(self.current_token[0])
                    return VariableNode(type_annotation, var_name)
                return VariableNode(type_name, var_name)
            elif self.current_token[0] == "LPAREN":
                return self.parse_postfix_suffixes(
                    self.parse_vector_constructor(type_name)
                )
            return type_name
        elif self.current_token[0] == "LPAREN":
            self.eat("LPAREN")
            expr = self.parse_expression()
            self.eat("RPAREN")
            return self.parse_postfix_suffixes(expr)
        elif self.current_token[0] in ["FN", "DEF", "STRUCT", "CLASS", "LET", "VAR"]:
            raise SyntaxError(f"Unexpected top-level keyword: {self.current_token[0]}")
        else:
            raise SyntaxError(
                f"Unexpected token in expression: {self.current_token[0]}"
            )

    def parse_vector_constructor(self, type_name):
        self.eat("LPAREN")
        args = []
        self.skip_layout_tokens()
        while self.current_token[0] != "RPAREN":
            args.append(self.parse_expression())
            self.skip_layout_tokens()
            if self.current_token[0] == "COMMA":
                self.eat("COMMA")
                self.skip_layout_tokens()
            elif self.current_token[0] != "RPAREN":
                raise SyntaxError(
                    f"Expected COMMA or RPAREN, got {self.current_token[0]}"
                )
        self.eat("RPAREN")
        return VectorConstructorNode(type_name, args)

    def parse_function_call_or_identifier(self):
        if self.current_token[0] == "IDENTIFIER":
            name = self.current_token[1]
            self.eat("IDENTIFIER")
            return self.parse_postfix_suffixes(VariableNode("", name))

        elif self.current_token[0] == "NUMBER":
            value = self.current_token[1]
            self.eat("NUMBER")
            return value

        else:
            raise SyntaxError(
                f"Expected IDENTIFIER or NUMBER, got {self.current_token[0]}"
            )

    def parse_postfix_suffixes(self, node):
        while True:
            if self.current_token[0] == "LPAREN":
                node = self.parse_call(node)
                continue

            if self.current_token[0] == "DOT":
                self.eat("DOT")
                if self.current_token[0] != "IDENTIFIER":
                    raise SyntaxError(
                        f"Expected IDENTIFIER after dot, got {self.current_token[0]}"
                    )
                member = self.current_token[1]
                self.eat("IDENTIFIER")
                node = MemberAccessNode(node, member)
                continue

            if self.current_token[0] == "LBRACKET":
                if self.is_generic_constructor_suffix(node):
                    type_name = node.name + self.parse_generic_type_suffix()
                    node = self.parse_vector_constructor(type_name)
                else:
                    node = self.parse_array_access(node)
                continue

            if self.current_token[0] == "AS":
                self.eat("AS")
                node = CastNode(self.parse_type(), node)
                continue

            return node

    def parse_call(self, callee):
        self.eat("LPAREN")
        args = []
        self.skip_layout_tokens()
        while self.current_token[0] != "RPAREN":
            args.append(self.parse_expression())
            self.skip_layout_tokens()
            if self.current_token[0] == "COMMA":
                self.eat("COMMA")
                self.skip_layout_tokens()
            elif self.current_token[0] != "RPAREN":
                raise SyntaxError(
                    f"Expected COMMA or RPAREN, got {self.current_token[0]}"
                )
        self.eat("RPAREN")
        if isinstance(callee, VariableNode):
            return FunctionCallNode(callee.name, args)
        if isinstance(callee, MemberAccessNode):
            return MethodCallNode(callee.object, callee.member, args)
        return CallNode(callee, args)

    def parse_decorator(self):
        self.eat("DECORATOR")
        name = self.current_token[1]
        args = []
        if self.current_token[0] == "LPAREN":
            self.eat("LPAREN")
            while self.current_token[0] != "RPAREN":
                args.append(self.parse_expression())
                if self.current_token[0] == "COMMA":
                    self.eat("COMMA")
            self.eat("RPAREN")
        return DecoratorNode(name, args)

    def parse_array_access(self, array):
        self.eat("LBRACKET")
        index = self.parse_expression()
        self.eat("RBRACKET")
        return ArrayAccessNode(array, index)

    def is_generic_constructor_suffix(self, node):
        if not isinstance(node, VariableNode) or self.current_token[0] != "LBRACKET":
            return False

        index = self.pos + 1
        depth = 1
        first_arg = None
        has_generic_marker = False

        while index < len(self.tokens):
            token_type, token_value = self.tokens[index]
            if token_type == "LBRACKET":
                depth += 1
            elif token_type == "RBRACKET":
                depth -= 1
                if depth == 0:
                    next_token = (
                        self.tokens[index + 1]
                        if index + 1 < len(self.tokens)
                        else ("EOF", None)
                    )
                    return next_token[0] == "LPAREN" and (
                        has_generic_marker or self.is_type_argument_token(first_arg)
                    )
            elif depth == 1:
                if first_arg is None and token_type not in {"COMMA"}:
                    first_arg = (token_type, token_value)
                if token_type in {"COMMA", "DOT"}:
                    has_generic_marker = True
                elif self.is_type_argument_token((token_type, token_value)):
                    has_generic_marker = True

            index += 1

        return False

    def is_type_argument_token(self, token):
        if token is None:
            return False
        token_type, token_value = token
        if token_type in {"INT", "FLOAT", "BOOL", "STRING"}:
            return True
        if token_type == "IDENTIFIER" and token_value:
            return token_value[0].isupper()
        return False

    def parse_type(self):
        if self.current_token[0] not in self.TYPE_START_TOKENS:
            raise SyntaxError(f"Expected type name, got {self.current_token[0]}")

        type_name = self.current_token[1]
        self.eat(self.current_token[0])
        if self.current_token[0] == "LBRACKET":
            type_name += self.parse_generic_type_suffix()
        return type_name

    def parse_generic_type_suffix(self):
        suffix = "["
        depth = 1
        self.eat("LBRACKET")

        while depth > 0:
            if self.current_token[0] == "EOF":
                raise SyntaxError("Unterminated generic type argument list")

            token_type, token_value = self.current_token
            if token_type == "LBRACKET":
                suffix += "["
                depth += 1
                self.eat("LBRACKET")
            elif token_type == "RBRACKET":
                suffix += "]"
                depth -= 1
                self.eat("RBRACKET")
            elif token_type == "COMMA":
                suffix += ", "
                self.eat("COMMA")
            else:
                suffix += token_value
                self.eat(token_type)

        return suffix
